class Hexagon extends BaseClass {
  constructor(x,y){
    super(x,y,50,50);
  }

  display() {
    
    super.display();
  }
}
